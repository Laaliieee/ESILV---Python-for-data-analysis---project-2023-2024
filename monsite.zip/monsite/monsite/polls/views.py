from django.http import HttpResponse
from django.template import loader 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import base64
from django.shortcuts import render 
import numpy as np

#pour faire apparaitre certain graphe, il faut desactiver l'affichage interactif 
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import pandas as pd
from django.shortcuts import render

#pour la carte 
import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt


def index(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    sns.set(style="whitegrid")

    # Création d'un diagramme à barres pour la consommation moyenne de cannabis par tranche d'âge
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Age', y='Cannabis', data=df, ci=None, palette="mako")

    # Configuration des étiquettes et titre
    plt.xlabel('Tranche d\'âge')
    plt.ylabel('Fréquence moyenne de consommation')
    plt.title('Consommation moyenne de Cannabis par tranche âge')

    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()

    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)
    #return HttpResponse(template.render(context, request))
    
    

def index1(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    sns.set(style="whitegrid")

    # Création d'un diagramme à barres pour la consommation moyenne de cannabis par tranche d'âge
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Age', y='Cannabis', data=df, ci=None, palette="mako")

    # Configuration des étiquettes et titre
    plt.xlabel('Tranche d\'âge')
    plt.ylabel('Fréquence moyenne de consommation')
    plt.title('Consommation moyenne de Cannabis par tranche âge')

    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template1.html', context)
    #return HttpResponse(template.render(context, request))

def index2(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    sns.set(style="whitegrid")

    # Création d'un diagramme à barres pour la consommation moyenne de cannabis par tranche d'âge
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Age', y='Cannabis', data=df, ci=None, palette="mako")

    # Configuration des étiquettes et titre
    plt.xlabel('Tranche d\'âge')
    plt.ylabel('Fréquence moyenne de consommation')
    plt.title('Consommation moyenne de Cannabis par tranche âge')

    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)
    #return HttpResponse(template.render(context, request))
    

def index3(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    # Filtrage des données pour la tranche d'âge 18-24 ans
    data_18_24 = df[df['Age'] == '18-24']

# Sélection des colonnes correspondant aux différentes drogues
    drug_columns = data_18_24.columns[13:]  # Les colonnes des drogues commencent après les 12 premières colonnes

# Calcul de la consommation moyenne de chaque drogue dans la tranche d'âge 18-24
    drug_usage_18_24 = data_18_24[drug_columns].mean().sort_values(ascending=False)

# Création du graphique
    plt.figure(figsize=(12, 8))
    sns.barplot(x=drug_usage_18_24.values, y=drug_usage_18_24.index, palette="viridis")

# Configuration des étiquettes et titre
    plt.xlabel('Fréquence moyenne de consommation')
    plt.ylabel('Drogue')
    plt.title('Fréquence moyenne de consommation de drogues chez les 18-24 ans')
# Affichage du gra

    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)
    #return HttpResponse(template.render(context, request))    


def index4(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    # Filtrage des données pour la tranche d'âge 18-24 ans
    data_18_24 = df[df['Age'] == '18-24']

# Sélection des colonnes correspondant aux différentes drogues
    drug_columns = data_18_24.columns[13:]  # Les colonnes des drogues commencent après les 12 premières colonnes

# Calcul de la consommation moyenne de chaque drogue dans la tranche d'âge 18-24
    drug_usage_18_24 = data_18_24[drug_columns].mean().sort_values(ascending=False)

    # Calcul de la consommation moyenne de chaque drogue par tranche d'âge
    avg_drug_use_by_age = df.groupby('Age')[drug_columns].mean()

# Identification de la drogue la plus consommée dans chaque tranche d'âge
    most_used_drug_by_age = avg_drug_use_by_age.idxmax(axis=1)

# Préparation des données pour la visualisation
    most_used_drug_data = most_used_drug_by_age.reset_index()
    most_used_drug_data.columns = ['Age', 'Most Used Drug']

# Affichage des résultats pour vérification
    most_used_drug_data
# Configuration du graphique
    plt.figure(figsize=(15, 12))
    number_of_drugs = len(drug_columns)
    colors = plt.cm.viridis(np.linspace(0, 1, number_of_drugs))

# Création d'un graphique pour chaque drogue
    for i, drug in enumerate(drug_columns):
        plt.subplot((number_of_drugs + 2) // 3, 3, i + 1)
        sns.barplot(x=avg_drug_use_by_age.index, y=avg_drug_use_by_age[drug], color=colors[i])
        plt.title(drug)
        plt.ylabel('Fréquence moy')
        plt.xlabel('Tranche d\'âge')

# Ajustement de l'espacement entre les graphiques
    plt.tight_layout()

# Affichage du graphique
    plt.show()
    
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)
    #return HttpResponse(template.render(context, request))    

def index5(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    # Filtrage des données pour la tranche d'âge 18-24 ans
    data_18_24 = df[df['Age'] == '18-24']

# Sélection des colonnes correspondant aux différentes drogues
    drug_columns = data_18_24.columns[13:]  # Les colonnes des drogues commencent après les 12 premières colonnes

# Calcul de la consommation moyenne de chaque drogue par pays
    avg_drug_use_by_country = df.groupby('Country')[drug_columns].mean()

# Configuration du graphique
    plt.figure(figsize=(15, 20))
    number_of_drugs = len(drug_columns)

# Création d'un graphique pour chaque drogue
    for i, drug in enumerate(drug_columns):
        plt.subplot((number_of_drugs + 2) // 3, 3, i + 1)
        sns.barplot(x=avg_drug_use_by_country[drug], y=avg_drug_use_by_country.index, palette="coolwarm")
        plt.title(drug)
        plt.xlabel('Fréquence moyenne')
        plt.ylabel('Pays')

# Ajustement de l'espacement entre les graphiques
    plt.tight_layout()

# Affichage du graphique
    plt.show()
    
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)


def index6(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    ethnicity_count = df['Ethnicity'].value_counts()
    plt.figure(figsize=(10, 7))
    ethnicity_count.plot(kind='bar', color='skyblue')
    plt.title('Répartition selon les ethnies des personnes participants au sondage')
    plt.xlabel('Groupe ethnique')
    plt.ylabel('Nombre de personnes')
    plt.show()
   
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)    
 

def index7(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    country_count = df['Country'].value_counts()
    plt.figure(figsize=(10, 6))
    country_count.plot(kind='bar', color='#FF8080')
    plt.title('Répartition selon les pays des personnes participants au sondage')
    plt.xlabel('Country')
    plt.ylabel('Nombre de personnes')
    plt.show()
   
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context)    


def index8(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    df_white_UK = df.loc[(df['Country'] == 'UK') & (df['Ethnicity'] == 'White') ]   
    colormap = sns.color_palette("Set2", n_colors=len(df_white_UK['Education'].unique()))
    plt.figure(figsize=(10, 10))
    df_white_UK['Education'].value_counts().plot(kind='pie', autopct='%1.1f%%', colors=colormap)
    plt.title('Distribution of Education Levels')
    plt.show()
   
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context) 



def index8(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    df_white_UK = df.loc[(df['Country'] == 'UK') & (df['Ethnicity'] == 'White') ]   
    colormap = sns.color_palette("Set2", n_colors=len(df_white_UK['Education'].unique()))
    plt.figure(figsize=(10, 10))
    df_white_UK['Education'].value_counts().plot(kind='pie', autopct='%1.1f%%', colors=colormap)
    plt.title('Distribution of Education Levels')
    plt.show()
   
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context) 

def index9(request):
    df = pd.read_csv(r"C:\Users\douni\Documents\ESILV A4\ESILV A4\Python for data analysis\Projet\drug.csv")
    
    # Charger le fichier de données géographiques du monde (pays)
    world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

    df['Country'] = df['Country'].replace({'UK': 'United Kingdom',
                                       'USA' : 'United States of America'})

# Compter le nombre de participants par pays
    participants_by_country = df['Country'].value_counts().reset_index()
    participants_by_country.columns = ['Country', 'Participants']

# Fusionner les données géographiques avec les données sur le nombre de participants
    world = world.merge(participants_by_country, how='left', left_on='name', right_on='Country')

# Remplacer les valeurs NaN par 0
    world['Participants'].fillna(0, inplace=True)

    fig, ax = plt.subplots(1, 1, figsize=(15, 10))
    world.boundary.plot(ax=ax)
    world.plot(column='Participants', ax=ax, legend=True, legend_kwds={'label': "Nombre de Participants par Pays", 'orientation': "horizontal"})
    plt.show()
   
    # Enregistrez le graphique dans un objet BytesIO
    from io import BytesIO
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)  

    # Convertissez le graphique en encodage base64
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    
    #template = loader.get_template('template0.html')
    context = {
        'plot_base64': plot_base64,
    }
    return render(request, 'template0.html', context) 


#Pour definir chaque index à une image   
    
def indextotal(request):
    template = loader.get_template('template1.html')
    
    if(request.GET['model']=="1"):
        return index2(request)
    if(request.GET['model']=="2"):
        return index3(request)
    if(request.GET['model']=="3"):
        return index4(request)
    if(request.GET['model']=="4"):
        return index5(request)
    if(request.GET['model']=="5"):
        return index6(request)
    if(request.GET['model']=="6"):
        return index7(request)
    if(request.GET['model']=="7"):
        return index8(request)
    if(request.GET['model']=="8"):
        return index9(request)

